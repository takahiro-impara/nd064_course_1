python init_db.py
python app.py